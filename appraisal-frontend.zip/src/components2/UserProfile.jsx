import Sidebar from "../components3/SideBar";

const UserProfile = () => {
  return (
    <>
      <Sidebar />
    </>
  );
};

export default UserProfile;
