// import { useContext } from "react";
// import { ThemeContext } from "./contexts/theme";

import About from "./About/About";
import "./UserProfile.css";
import Contact from "./Contact/Contact";
import Header from "./Header/Header";
import Projects from "./Projects/Projects";
import ScrollToTop from "./ScrollToTop/ScrollToTop";
import Skills from "./Skills/Skills";
import Footer from "./Footer/Footer";
import Sidebar from "../components3/SideBar";
import EmployeeSideBar from "../components3/EmployeeSideBar";
import { BasicProgressBarWithLabel } from "../components4/ProgressBar";

const UserProfile = () => {
  return (
    <>
      <EmployeeSideBar />

      {/* <div id="top" className="container">
        <Header />
        <h2>The dog in pot</h2>
        <main>
          <BasicProgressBarWithLabel
            currentValue={45}
            maxValue={100}
            label={"ProgressBar"}
          />
          <About />
          <Projects />
          <Skills />
          <Contact />
        </main>

        <ScrollToTop />
        <Footer />
      </div> */}
    </>
  );
};

export default UserProfile;
